@echo off
set APP_HOME=%~dp0
if "%JAVA_HOME%"=="" (
  set JAVACMD=java.exe
) else (
  set JAVACMD=%JAVA_HOME%\bin\java.exe
)
set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar
"%JAVACMD%" %JAVA_OPTS% %GRADLE_OPTS% -Dorg.gradle.appname=gradlew -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
