package com.voicepilot.agent.core

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.net.URI

object AgentPreferences {
    private const val FILE = "voicepilot_secure_settings"
    private const val KEY_BACKEND = "backend_url"
    private const val KEY_TOKEN = "backend_token"
    private const val KEY_OVERLAY = "overlay_enabled"

    private fun store(context: Context) = EncryptedSharedPreferences.create(
        context,
        FILE,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun backendUrl(context: Context): String = store(context).getString(KEY_BACKEND, "") ?: ""
    fun bearerToken(context: Context): String = store(context).getString(KEY_TOKEN, "") ?: ""
    fun overlayEnabled(context: Context): Boolean = store(context).getBoolean(KEY_OVERLAY, false)

    fun saveBackend(context: Context, url: String, token: String) {
        val normalized = url.trim().trimEnd('/')
        val uri = runCatching { URI(normalized) }.getOrElse { throw IllegalArgumentException("Invalid backend URL") }
        require(uri.scheme.equals("https", ignoreCase = true) && !uri.host.isNullOrBlank() && uri.userInfo == null) {
            "Backend URL must be an HTTPS URL without embedded credentials"
        }
        require(uri.rawQuery == null && uri.rawFragment == null) {
            "Backend URL must not include a query string or fragment"
        }
        require(token.length in 16..512 && token.none(Char::isWhitespace)) { "Use a 16–512 character bearer token" }
        store(context).edit().putString(KEY_BACKEND, normalized).putString(KEY_TOKEN, token).apply()
    }

    fun setOverlayEnabled(context: Context, enabled: Boolean) {
        store(context).edit().putBoolean(KEY_OVERLAY, enabled).apply()
    }
}
