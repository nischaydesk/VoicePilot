package com.voicepilot.agent.core

object SafetyPolicy {
    private val purchaseRisk = Regex(
        "(?i)(checkout|check\\s*out|payment|pay\\s*(?:now|for)|purchase|buy\\b|order\\s+placement|place\\s+(?:an?\\s+|the\\s+)?order|confirm\\s+(?:the\\s+)?order|final\\s+(?:submit|click|confirmation)|submit\\s+(?:the\\s+)?order|book(?:ing)?\\b|money\\s+transfer|transfer\\s+money|send\\s+money|complete\\s+(?:the\\s+)?(?:order|purchase)|payee|ऑर्डर\\s*(?:करें|प्लेस)|भुगतान|अभी\\s*खरीद|खरीदें|खरीदारी|पैसे\\s*दे)",
    )
    private val paymentEntry = Regex(
        "(?i)(card\\b|card\\s*number|cvv|security\\s*code|upi\\s*pin|\\bpin\\b|otp|one.time.password|password|passcode|debit\\s*card|credit\\s*card|bank\\s*account|account\\s*number|routing\\s*number|ifsc|कार्ड\\s*नंबर|ओटीपी|सीवीवी|पासवर्ड|पिन)",
    )

    fun requiresConfirmation(intent: String, targetLabel: String?, visibleText: String, action: ActionKind): Boolean {
        if (action != ActionKind.CLICK) return false
        return purchaseRisk.containsMatchIn(intent) ||
            (!targetLabel.isNullOrBlank() && purchaseRisk.containsMatchIn(targetLabel)) ||
            purchaseRisk.containsMatchIn(visibleText)
    }

    fun isSensitiveInput(visibleText: String): Boolean = paymentEntry.containsMatchIn(visibleText)

    fun isAffirmativeConfirmation(phrase: String): Boolean {
        val normalized = phrase.trim().lowercase()
            .replace(Regex("[,!.?]+"), " ")
            .replace(Regex("\\s+"), " ")
        if (normalized.length > 80) return false
        val negative = Regex("(?i)(\\b(cancel|no|nahi|nahin|mat|maybe|perhaps|unsure|wait|not sure|not certain|i think|i guess)\\b|नहीं|मत\\s*करो|don't|do not|रद्द)")
        if (negative.containsMatchIn(normalized)) return false
        return Regex("(?i)^(?:yes|yeah|yep|haan|ha|हाँ|हां|confirm|proceed|approve|(?:please\\s+)?confirm(?:\\s+(?:karo|kar do))?|(?:yes|haan|ha)\\s+(?:confirm|proceed|approve)(?:\\s+(?:karo|kar do))?|(?:जी\\s+)?(?:हाँ|हां)\\s+(?:confirm|कन्फर्म|पुष्टि)(?:\\s+(?:karo|करो|कर\\s+दो))?)$")
            .matches(normalized)
    }
}
