package com.voicepilot.agent.net

import android.util.Base64
import com.voicepilot.agent.core.ActionParser
import com.voicepilot.agent.core.AgentAction
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

class BackendClient(
    private val baseUrl: String,
    private val bearerToken: String,
) {
    fun decide(intent: String, jpeg: ByteArray, width: Int, height: Int): AgentAction {
        require(jpeg.isNotEmpty() && jpeg.size <= MAX_IMAGE_BYTES) { "Screen capture is empty or too large" }
        require(intent.isNotBlank() && intent.length <= 1200) { "Voice command is empty or too long" }
        require(width > 0 && height > 0) { "Invalid capture dimensions" }
        require(baseUrl.startsWith("https://", ignoreCase = true)) { "Backend HTTPS is required" }

        val request = JSONObject()
            .put("intent", intent.trim())
            .put("image_base64", Base64.encodeToString(jpeg, Base64.NO_WRAP))
            .put("mime_type", "image/jpeg")
            .put("screen_width", width)
            .put("screen_height", height)
            .toString()
            .toByteArray(Charsets.UTF_8)

        val connection = (URL("${baseUrl.trimEnd('/')}/v1/decide").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10_000
            readTimeout = 35_000
            instanceFollowRedirects = false
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $bearerToken")
            setFixedLengthStreamingMode(request.size)
        }
        try {
            connection.outputStream.use { it.write(request) }
            val status = connection.responseCode
            val responseStream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseBytes = responseStream?.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(1024)
                var total = 0
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    require(total <= MAX_RESPONSE_BYTES) { "Decision API response is too large" }
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            } ?: ByteArray(0)
            if (status !in 200..299) throw IllegalStateException("Decision API failed with HTTP $status")
            val body = String(responseBytes, Charsets.UTF_8)
            return ActionParser.parse(body, width, height)
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val MAX_IMAGE_BYTES = 3 * 1024 * 1024
        private const val MAX_RESPONSE_BYTES = 4096
    }
}
