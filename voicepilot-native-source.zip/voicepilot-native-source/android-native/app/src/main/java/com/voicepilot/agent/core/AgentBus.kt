package com.voicepilot.agent.core

object AgentBus {
    const val ACTION_EXECUTE = "com.voicepilot.agent.action.EXECUTE"
    const val ACTION_CONFIRM_PROMPT = "com.voicepilot.agent.action.CONFIRM_PROMPT"
    const val ACTION_CONFIRM_RESULT = "com.voicepilot.agent.action.CONFIRM_RESULT"
    const val ACTION_REFRESH_OVERLAY = "com.voicepilot.agent.action.REFRESH_OVERLAY"
    const val ACTION_STOP_LISTENING = "com.voicepilot.agent.action.STOP_LISTENING"
    const val ACTION_CONFIRM_TAP = "com.voicepilot.agent.action.CONFIRM_TAP"
    const val ACTION_CANCEL_PENDING = "com.voicepilot.agent.action.CANCEL_PENDING"
    const val ACTION_SPEAK = "com.voicepilot.agent.action.SPEAK"
    const val ACTION_AGENT_RESULT = "com.voicepilot.agent.action.AGENT_RESULT"

    const val EXTRA_ACTION_JSON = "action_json"
    const val EXTRA_INTENT = "voice_intent"
    const val EXTRA_PENDING_ID = "pending_id"
    const val EXTRA_PROMPT = "confirm_prompt"
    const val EXTRA_APPROVED = "approved"
    const val EXTRA_SCREEN_WIDTH = "screen_width"
    const val EXTRA_SCREEN_HEIGHT = "screen_height"
    const val EXTRA_SPEECH = "speech_text"
}
