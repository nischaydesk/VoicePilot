package com.voicepilot.agent.core

import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONException
import org.json.JSONObject
import java.io.StringReader

private val ACTION_KEYS = setOf("action", "coordinates", "text_payload", "speech_response")
private val COORDINATE_KEYS = setOf("x", "y")
private val STRICT_INTEGER = Regex("-?(?:0|[1-9][0-9]*)")

enum class ActionKind { CLICK, TYPE, SWIPE, SPEAK }

data class ScreenPoint(val x: Int, val y: Int)

data class AgentAction(
    val action: ActionKind,
    val coordinates: ScreenPoint?,
    val textPayload: String?,
    val speechResponse: String,
) {
    fun toJson(): String = JSONObject()
        .put("action", action.name)
        .put("coordinates", coordinates?.let { JSONObject().put("x", it.x).put("y", it.y) } ?: JSONObject.NULL)
        .put("text_payload", textPayload ?: JSONObject.NULL)
        .put("speech_response", speechResponse)
        .toString()
}

object ActionParser {
    fun parse(json: String, screenWidth: Int, screenHeight: Int): AgentAction {
        require(screenWidth > 0 && screenHeight > 0) { "Invalid screen dimensions" }
        require(json.isNotBlank() && json.length <= MAX_RESPONSE_CHARS) { "Action JSON is empty or too large" }

        val reader = JsonReader(StringReader(json)).apply { isLenient = false }
        reader.beginObject()
        val seen = mutableSetOf<String>()
        var actionValue: String? = null
        var coordinates: ScreenPoint? = null
        var coordinatesSeen = false
        var payload: String? = null
        var payloadSeen = false
        var speech: String? = null

        while (reader.hasNext()) {
            val key = reader.nextName()
            require(seen.add(key)) { "Duplicate action field: $key" }
            when (key) {
                "action" -> actionValue = readString(reader, key)
                "coordinates" -> {
                    coordinatesSeen = true
                    coordinates = if (reader.peek() == JsonToken.NULL) {
                        reader.nextNull()
                        null
                    } else {
                        readCoordinates(reader)
                    }
                }
                "text_payload" -> {
                    payloadSeen = true
                    payload = readNullableString(reader, key, MAX_PAYLOAD_CHARS)
                }
                "speech_response" -> speech = readString(reader, key)
                else -> throw IllegalArgumentException("Unknown action field: $key")
            }
        }
        reader.endObject()
        require(reader.peek() == JsonToken.END_DOCUMENT) { "Trailing JSON data is not allowed" }
        require(seen == ACTION_KEYS && coordinatesSeen && payloadSeen) { "Action JSON has missing or unknown fields" }

        val action = try {
            ActionKind.valueOf(actionValue ?: throw IllegalArgumentException("Missing action"))
        } catch (e: Exception) {
            throw IllegalArgumentException("Unsupported action", e)
        }
        val speechResponse = speech?.trim().orEmpty()
        require(speechResponse.isNotEmpty() && speechResponse.length <= MAX_SPEECH_CHARS) {
            "speech_response is empty or too long"
        }
        coordinates?.let { point ->
            require(point.x in 0 until screenWidth && point.y in 0 until screenHeight) {
                "Coordinates are outside the screen"
            }
        }

        when (action) {
            ActionKind.CLICK -> {
                require(coordinates != null) { "CLICK requires coordinates" }
                require(!payload.isNullOrBlank()) { "CLICK requires the visible target label" }
            }
            ActionKind.SWIPE -> {
                require(coordinates != null) { "SWIPE requires coordinates" }
                require(payload == null) { "SWIPE cannot carry text_payload" }
            }
            ActionKind.TYPE -> {
                require(coordinates != null) { "TYPE requires target coordinates" }
                require(!payload.isNullOrBlank()) { "TYPE requires text_payload" }
            }
            ActionKind.SPEAK -> require(coordinates == null && payload == null) {
                "SPEAK cannot carry coordinates or text_payload"
            }
        }
        return AgentAction(action, coordinates, payload, speechResponse)
    }

    private fun readCoordinates(reader: JsonReader): ScreenPoint {
        reader.beginObject()
        val seen = mutableSetOf<String>()
        var x: Int? = null
        var y: Int? = null
        while (reader.hasNext()) {
            val key = reader.nextName()
            require(seen.add(key)) { "Duplicate coordinate field: $key" }
            when (key) {
                "x" -> x = readExactInt(reader, key)
                "y" -> y = readExactInt(reader, key)
                else -> throw IllegalArgumentException("Unknown coordinate field: $key")
            }
        }
        reader.endObject()
        require(seen == COORDINATE_KEYS) { "Coordinates require x and y" }
        return ScreenPoint(x ?: error("Missing coordinate x"), y ?: error("Missing coordinate y"))
    }

    private fun readExactInt(reader: JsonReader, key: String): Int {
        require(reader.peek() == JsonToken.NUMBER) { "$key must be an integer" }
        val raw = reader.nextString()
        require(STRICT_INTEGER.matches(raw)) { "$key must be an integer" }
        return raw.toIntOrNull() ?: throw IllegalArgumentException("$key is outside integer range")
    }

    private fun readString(reader: JsonReader, key: String): String {
        require(reader.peek() == JsonToken.STRING) { "$key must be a string" }
        return reader.nextString()
    }

    private fun readNullableString(reader: JsonReader, key: String, maxLength: Int): String? {
        if (reader.peek() == JsonToken.NULL) {
            reader.nextNull()
            return null
        }
        val value = readString(reader, key)
        require(value.length <= maxLength) { "$key is too long" }
        return value
    }

    private const val MAX_RESPONSE_CHARS = 4096
    private const val MAX_PAYLOAD_CHARS = 240
    private const val MAX_SPEECH_CHARS = 320
}
