package com.voicepilot.agent.ui

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import com.voicepilot.agent.accessibility.AgentAccessibilityService
import com.voicepilot.agent.capture.ScreenCaptureService
import com.voicepilot.agent.core.AgentBus
import com.voicepilot.agent.core.AgentPreferences
import com.voicepilot.agent.voice.VoiceCommandService

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var backendField: EditText
    private lateinit var tokenField: EditText
    private lateinit var captureButton: Button
    private lateinit var overlayButton: Button
    private lateinit var listenButton: Button

    private val projectionConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            Toast.makeText(this, "Screen capture permission granted for this session", Toast.LENGTH_LONG).show()
            status.postDelayed({ refreshStatus() }, 700)
        } else {
            Toast.makeText(this, "Screen capture was not started", Toast.LENGTH_SHORT).show()
        }
    }

    private val runtimePermissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshStatus()
        if (it.values.all { granted -> granted }) startVoiceAssistant()
        else Toast.makeText(this, "Microphone and notification permissions are required to listen visibly", Toast.LENGTH_LONG).show()
    }

    private val settingsResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        refreshStatus()
        notifyAccessibilityService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        backendField.setText(AgentPreferences.backendUrl(this))
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        notifyAccessibilityService()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(28))
            setBackgroundColor(getColor(com.voicepilot.agent.R.color.paper))
        }
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)

        page.addView(TextView(this).apply {
            text = "VoicePilot"
            textSize = 30f
            setTextColor(getColor(com.voicepilot.agent.R.color.ink))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }, params(bottom = 4))
        page.addView(TextView(this).apply {
            text = "Hindi voice assistance for the app currently on screen. Capture and actions remain visible and user-controlled."
            textSize = 15f
            setTextColor(getColor(com.voicepilot.agent.R.color.ink_soft))
        }, params(bottom = 16))

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(getColor(com.voicepilot.agent.R.color.ink))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(getColor(com.voicepilot.agent.R.color.jade_light))
        }
        page.addView(status, params(bottom = 16))

        page.addView(sectionTitle("1 · Configure private backend"), params(bottom = 6))
        backendField = EditText(this).apply {
            hint = "https://your-server.example"
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(AgentPreferences.backendUrl(this@MainActivity))
        }
        page.addView(backendField, params(bottom = 4))
        tokenField = EditText(this).apply {
            hint = "Backend bearer token (16+ characters)"
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        page.addView(tokenField, params(bottom = 6))
        page.addView(actionButton("Save HTTPS endpoint and token") { saveSettings() }, params(bottom = 14))

        page.addView(sectionTitle("2 · Allow Android capabilities"), params(bottom = 6))
        page.addView(actionButton("Open Accessibility settings") {
            settingsResult.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, params(bottom = 6))
        overlayButton = actionButton("Grant floating-widget permission") { requestOverlayPermission() }
        page.addView(overlayButton, params(bottom = 6))
        captureButton = actionButton("Grant screen-capture permission") { requestProjection() }
        page.addView(captureButton, params(bottom = 6))
        page.addView(actionButton("End screen-capture session") { stopProjection() }, params(bottom = 14))

        page.addView(sectionTitle("3 · Start or stop voice assistant"), params(bottom = 6))
        listenButton = actionButton("Start visible microphone service") { requestOrStartVoice() }
        page.addView(listenButton, params(bottom = 6))
        page.addView(actionButton("Stop listening and discard pending action") { stopVoiceService() }, params(bottom = 12))
        page.addView(TextView(this).apply {
            text = "Screen images and voice transcripts are sent to the configured HTTPS backend for decisions. Android SpeechRecognizer may use a remote recognition provider. VoicePilot does not enter card details, OTPs, or payment credentials. You can stop the microphone service from the app or its notification."
            textSize = 13f
            setTextColor(getColor(com.voicepilot.agent.R.color.ink_soft))
        })
    }

    private fun requestOrStartVoice() {
        if (AgentPreferences.backendUrl(this).isBlank() || AgentPreferences.bearerToken(this).isBlank()) {
            Toast.makeText(this, "Save the backend URL and token first", Toast.LENGTH_LONG).show()
            return
        }
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "Enable VoicePilot in Android Accessibility settings first", Toast.LENGTH_LONG).show()
            settingsResult.launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant floating-widget permission first", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        val projectionReady = getSharedPreferences(ScreenCaptureService.PREFS, MODE_PRIVATE)
            .getBoolean(ScreenCaptureService.KEY_READY, false)
        if (!projectionReady) {
            Toast.makeText(this, "Grant screen capture for this session first", Toast.LENGTH_LONG).show()
            requestProjection()
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        if (needed.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            runtimePermissions.launch(needed.toTypedArray())
            return
        }
        startVoiceAssistant()
    }

    private fun startVoiceAssistant() {
        if (AgentPreferences.backendUrl(this).isBlank() || AgentPreferences.bearerToken(this).isBlank()) return
        val service = Intent(this, VoiceCommandService::class.java).apply { action = VoiceCommandService.ACTION_START }
        ContextCompat.startForegroundService(this, service)
        status.postDelayed({ refreshStatus() }, 500)
    }

    private fun saveSettings() {
        val token = if (tokenField.text.isNullOrBlank()) AgentPreferences.bearerToken(this) else tokenField.text.toString()
        try {
            AgentPreferences.saveBackend(this, backendField.text.toString(), token)
            tokenField.text.clear()
            Toast.makeText(this, "Encrypted endpoint settings saved", Toast.LENGTH_SHORT).show()
            refreshStatus()
        } catch (e: IllegalArgumentException) {
            tokenField.error = e.message
            backendField.error = "Use an HTTPS URL and a valid bearer token"
        }
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            AgentPreferences.setOverlayEnabled(this, true)
            notifyAccessibilityService()
            refreshStatus()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        settingsResult.launch(intent)
    }

    private fun requestProjection() {
        val alreadyRunning = getSharedPreferences(ScreenCaptureService.PREFS, MODE_PRIVATE)
            .getBoolean(ScreenCaptureService.KEY_READY, false)
        if (alreadyRunning) {
            Toast.makeText(this, "Screen capture is already active for this session", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = getSystemService(MediaProjectionManager::class.java)
        projectionConsent.launch(manager.createScreenCaptureIntent())
    }

    private fun stopProjection() {
        startService(Intent(this, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_STOP })
        refreshStatus()
    }

    private fun stopVoiceService() {
        sendBroadcast(Intent(AgentBus.ACTION_STOP_LISTENING).setPackage(packageName))
        stopService(Intent(this, VoiceCommandService::class.java))
        Toast.makeText(this, "Voice listening stopped", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun notifyAccessibilityService() {
        if (!::overlayButton.isInitialized) return
        val allowed = Settings.canDrawOverlays(this)
        AgentPreferences.setOverlayEnabled(this, allowed)
        sendBroadcast(Intent(AgentBus.ACTION_REFRESH_OVERLAY).setPackage(packageName))
        overlayButton.text = if (allowed) "Floating-widget permission granted" else "Grant floating-widget permission"
    }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        val projection = getSharedPreferences(ScreenCaptureService.PREFS, MODE_PRIVATE).getBoolean(ScreenCaptureService.KEY_READY, false)
        val overlay = Settings.canDrawOverlays(this)
        status.text = "Accessibility: ${if (isAccessibilityEnabled()) "enabled" else "not enabled"}\n" +
            "Overlay: ${if (overlay) "allowed" else "not allowed"}\n" +
            "Screen capture: ${if (projection) "active this session" else "consent required"}\n" +
            "Backend: ${if (AgentPreferences.backendUrl(this).isNotBlank()) "configured" else "not configured"}"
        if (::captureButton.isInitialized) {
            captureButton.text = if (projection) "Screen capture active · consent granted" else "Grant screen-capture permission"
        }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(this, AgentAccessibilityService::class.java).flattenToString()
        val setting = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        return setting.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun actionButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
        gravity = Gravity.CENTER
        setTextColor(getColor(com.voicepilot.agent.R.color.ink))
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 17f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setTextColor(getColor(com.voicepilot.agent.R.color.ink))
    }

    private fun params(bottom: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
    ).apply { bottomMargin = dp(bottom) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
