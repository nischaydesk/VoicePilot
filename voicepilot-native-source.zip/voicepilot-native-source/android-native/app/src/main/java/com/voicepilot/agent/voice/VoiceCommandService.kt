package com.voicepilot.agent.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.voicepilot.agent.R
import com.voicepilot.agent.capture.ScreenCaptureService
import com.voicepilot.agent.core.AgentBus
import com.voicepilot.agent.core.AgentPreferences
import com.voicepilot.agent.core.SafetyPolicy
import com.voicepilot.agent.net.BackendClient
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class VoiceCommandService : Service(), RecognitionListener {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val isRequestRunning = AtomicBoolean(false)
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listeningRequested = false
    private var confirming = false
    private var pendingId: String? = null
    private var suppressRecognizerErrorsUntil = 0L
    private var projectionBinder: ScreenCaptureService.LocalBinder? = null
    private var boundProjection = false

    private val captureConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            projectionBinder = service as? ScreenCaptureService.LocalBinder
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            projectionBinder = null
        }
    }

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                AgentBus.ACTION_CONFIRM_PROMPT -> onConfirmationPrompt(intent)
                AgentBus.ACTION_CONFIRM_RESULT -> onConfirmationResult(intent)
                AgentBus.ACTION_AGENT_RESULT -> {
                    val phrase = intent.getStringExtra(AgentBus.EXTRA_SPEECH).orEmpty()
                    if (phrase.isNotBlank()) speakAndResume(phrase)
                }
                AgentBus.ACTION_STOP_LISTENING -> stopListeningSession()
                AgentBus.ACTION_SPEAK -> {
                    val phrase = intent.getStringExtra(AgentBus.EXTRA_SPEECH).orEmpty()
                    if (phrase.isNotBlank()) speakAndResume(phrase)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale("hi", "IN")
                tts?.setSpeechRate(0.96f)
            }
        }
        val filter = IntentFilter().apply {
            addAction(AgentBus.ACTION_CONFIRM_PROMPT)
            addAction(AgentBus.ACTION_CONFIRM_RESULT)
            addAction(AgentBus.ACTION_AGENT_RESULT)
            addAction(AgentBus.ACTION_STOP_LISTENING)
            addAction(AgentBus.ACTION_SPEAK)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(commandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(commandReceiver, filter)
        }
        boundProjection = bindService(Intent(this, ScreenCaptureService::class.java), captureConnection, BIND_AUTO_CREATE)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListeningSession()
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        if (AgentPreferences.backendUrl(this).isBlank() || AgentPreferences.bearerToken(this).isBlank()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: SecurityException) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        listeningRequested = true
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speakAndResume("Is device par speech recognition available nahi hai.")
        } else {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                    it.setRecognitionListener(this)
                }
            }
            speakAndResume("Ji, abhi search kar raha hu. Aap apna command boliye.")
        }
        return START_NOT_STICKY
    }

    private fun startRecognition() {
        if (!listeningRequested || isRequestRunning.get() || confirming) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
        }
        val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        runCatching { recognizer?.startListening(request) }.onFailure {
            main.postDelayed({ startRecognition() }, 1500)
        }
        updateNotification("Listening in Hindi/Hinglish · tap Stop to pause")
    }

    override fun onReadyForSpeech(params: Bundle?) = Unit
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    override fun onError(error: Int) {
        if (!listeningRequested) return
        if (System.currentTimeMillis() <= suppressRecognizerErrorsUntil) return
        if (confirming) {
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                val id = pendingId
                confirming = false
                pendingId = null
                if (id != null) sendConfirmationDecision(id, false)
                speakAndResume("Confirmation nahi mili. Koi action nahi kiya.")
            } else {
                main.postDelayed({ startRecognition() }, 1000)
            }
            return
        }
        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || error == SpeechRecognizer.ERROR_CLIENT) {
            stopListeningSession()
            return
        }
        val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 700L
        main.postDelayed({ startRecognition() }, delay)
    }

    override fun onResults(results: Bundle?) {
        val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val transcript = phrases.firstOrNull()?.trim().orEmpty()
        if (transcript.isBlank()) {
            if (confirming) {
                val id = pendingId
                confirming = false
                pendingId = null
                if (id != null) sendConfirmationDecision(id, false)
                speakAndResume("Confirmation samajh nahi aayi. Koi action nahi kiya.")
            } else main.postDelayed({ startRecognition() }, 600)
            return
        }
        if (confirming) {
            val approved = SafetyPolicy.isAffirmativeConfirmation(transcript)
            val id = pendingId
            confirming = false
            pendingId = null
            if (id != null) sendConfirmationDecision(id, approved)
            if (!approved) speakAndResume("Theek hai, action cancel kar diya.")
            return
        }
        handleCommand(transcript)
    }

    override fun onPartialResults(partialResults: Bundle?) = Unit

    private fun handleCommand(transcript: String) {
        if (!isRequestRunning.compareAndSet(false, true)) return
        updateNotification("Processing one voice command")
        speak("Ji, abhi search kar raha hu.")
        worker.execute {
            try {
                val capture = projectionBinder?.captureFrame()
                    ?: throw IllegalStateException("Screen capture is unavailable. Grant capture permission again.")
                val action = BackendClient(
                    AgentPreferences.backendUrl(this),
                    AgentPreferences.bearerToken(this),
                ).decide(transcript, capture.jpeg, capture.width, capture.height)
                val execute = Intent(AgentBus.ACTION_EXECUTE).setPackage(packageName)
                    .putExtra(AgentBus.EXTRA_ACTION_JSON, action.toJson())
                    .putExtra(AgentBus.EXTRA_INTENT, transcript)
                    .putExtra(AgentBus.EXTRA_SCREEN_WIDTH, capture.width)
                    .putExtra(AgentBus.EXTRA_SCREEN_HEIGHT, capture.height)
                sendBroadcast(execute)
                main.post {
                    isRequestRunning.set(false)
                }
            } catch (error: Exception) {
                main.post {
                    isRequestRunning.set(false)
                    val message = when {
                        error.message.orEmpty().contains("capture", ignoreCase = true) -> "Screen capture band hai. App mein wapas jaakar dobara permission dijiye."
                        error.message.orEmpty().contains("HTTPS", ignoreCase = true) -> "Backend HTTPS URL check kijiye."
                        else -> "Request complete nahi hui. Koi action nahi kiya."
                    }
                    speakAndResume(message)
                }
            }
        }
    }

    private fun onConfirmationPrompt(intent: Intent) {
        val id = intent.getStringExtra(AgentBus.EXTRA_PENDING_ID) ?: return
        val prompt = intent.getStringExtra(AgentBus.EXTRA_PROMPT) ?: "Kya main is sensitive action ko proceed karu?"
        confirming = true
        pendingId = id
        cancelRecognitionSilently()
        speakAndResume(prompt + " Boliyega: haan confirm karo, ya nahin cancel.")
    }

    private fun onConfirmationResult(intent: Intent) {
        val id = intent.getStringExtra(AgentBus.EXTRA_PENDING_ID)
        if (id != pendingId) return
        val approved = intent.getBooleanExtra(AgentBus.EXTRA_APPROVED, false)
        val message = intent.getStringExtra(AgentBus.EXTRA_SPEECH).orEmpty()
        confirming = false
        pendingId = null
        cancelRecognitionSilently()
        if (!approved) speakAndResume(message.ifBlank { "Action cancelled. No action was performed." })
    }

    private fun sendConfirmationDecision(id: String, approved: Boolean) {
        sendBroadcast(
            Intent(AgentBus.ACTION_CONFIRM_RESULT).setPackage(packageName)
                .putExtra(AgentBus.EXTRA_PENDING_ID, id)
                .putExtra(AgentBus.EXTRA_APPROVED, approved),
        )
    }

    private fun speakAndResume(text: String) {
        if (!listeningRequested) return
        main.removeCallbacksAndMessages(REARM_TOKEN)
        if (ttsReady && tts != null) {
            val id = "voicepilot-${System.nanoTime()}"
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    main.postAtTime({ startRecognition() }, REARM_TOKEN, System.currentTimeMillis() + 350)
                }
                @Deprecated("Deprecated by Android")
                override fun onError(utteranceId: String?) {
                    main.postAtTime({ startRecognition() }, REARM_TOKEN, System.currentTimeMillis() + 700)
                }
            })
            tts?.speak(text.take(320), TextToSpeech.QUEUE_FLUSH, null, id)
        } else {
            main.postAtTime({ startRecognition() }, REARM_TOKEN, System.currentTimeMillis() + 1000)
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text.take(320), TextToSpeech.QUEUE_FLUSH, null, "voicepilot-${System.nanoTime()}")
    }

    private fun cancelRecognitionSilently() {
        suppressRecognizerErrorsUntil = System.currentTimeMillis() + 1200
        runCatching { recognizer?.cancel() }
    }

    private fun stopListeningSession() {
        listeningRequested = false
        confirming = false
        pendingId = null
        isRequestRunning.set(false)
        main.removeCallbacksAndMessages(REARM_TOKEN)
        cancelRecognitionSilently()
        stopSelf()
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, StopVoiceReceiver::class.java)
        val stopPending = PendingIntent.getBroadcast(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(getString(R.string.notification_listening))
            .setContentText("User-started · Hindi/Hinglish · Stop at any time")
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Stop", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification().let { notification ->
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(getString(R.string.notification_listening))
                .setContentText(text)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .addAction(0, "Stop", notification.actions?.firstOrNull()?.actionIntent)
                .build()
        })
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, getString(R.string.notification_channel_name), NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        listeningRequested = false
        runCatching { recognizer?.cancel() }
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        if (boundProjection) runCatching { unbindService(captureConnection) }
        runCatching { unregisterReceiver(commandReceiver) }
        worker.shutdownNow()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.voicepilot.agent.voice.START"
        const val ACTION_STOP = "com.voicepilot.agent.voice.STOP"
        private const val CHANNEL_ID = "voicepilot_microphone"
        private const val NOTIFICATION_ID = 4102
        private val REARM_TOKEN = Any()
    }
}

class StopVoiceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        context.sendBroadcast(Intent(AgentBus.ACTION_STOP_LISTENING).setPackage(context.packageName))
        context.stopService(Intent(context, VoiceCommandService::class.java))
    }
}
