package com.voicepilot.agent.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.roundToInt

class ScreenCaptureService : Service() {
    data class CapturedFrame(val jpeg: ByteArray, val width: Int, val height: Int)

    inner class LocalBinder : Binder() {
        fun captureFrame(timeoutMs: Long = 1800): CapturedFrame? = captureOne(timeoutMs)
        fun isReady(): Boolean = projection != null && imageReader != null
    }

    private val binder = LocalBinder()
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var imageThread: HandlerThread
    private lateinit var imageHandler: Handler
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var displayWidth = 0
    private var displayHeight = 0
    private var captureRequested = false
    private var sequence = 0L
    private var lastFrame: CapturedFrame? = null
    private val frameLock = Object()

    override fun onCreate() {
        super.onCreate()
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_READY, false).apply()
        imageThread = HandlerThread("VoicePilotFrameReader").apply { start() }
        imageHandler = Handler(imageThread.looper)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            releaseProjection()
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START) return START_NOT_STICKY
        if (projection != null) return START_NOT_STICKY
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val consentData = parcelableIntent(intent, EXTRA_RESULT_DATA)
        if (consentData == null || resultCode == 0) {
            stopSelf(startId)
            return START_NOT_STICKY
        }

        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            val manager = getSystemService(MediaProjectionManager::class.java)
            projection = manager.getMediaProjection(resultCode, consentData)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    releaseProjection(stopProjection = false)
                    stopSelf()
                }

                override fun onCapturedContentResize(width: Int, height: Int) {
                    if (width > 0 && height > 0) resizeCapture(width, height)
                }
            }, mainHandler)
            val bounds = screenSize()
            setUpCapture(bounds.first, bounds.second)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_READY, true).apply()
        } catch (_: SecurityException) {
            releaseProjection()
            stopSelf(startId)
        } catch (_: RuntimeException) {
            releaseProjection()
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun setUpCapture(width: Int, height: Int) {
        displayWidth = width
        displayHeight = height
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).apply {
            setOnImageAvailableListener({ reader -> consumeRequestedFrame(reader) }, imageHandler)
        }
        imageReader = reader
        virtualDisplay = projection?.createVirtualDisplay(
            "VoicePilotCapture",
            width,
            height,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            mainHandler,
        ) ?: throw IllegalStateException("Virtual display could not be created")
    }

    private fun resizeCapture(width: Int, height: Int) {
        if (projection == null || virtualDisplay == null || (width == displayWidth && height == displayHeight)) return
        runCatching {
            val replacement = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2).apply {
                setOnImageAvailableListener({ reader -> consumeRequestedFrame(reader) }, imageHandler)
            }
            val previous = imageReader
            imageReader = replacement
            displayWidth = width
            displayHeight = height
            virtualDisplay?.resize(width, height, resources.displayMetrics.densityDpi)
            virtualDisplay?.setSurface(replacement.surface)
            previous?.setOnImageAvailableListener(null, null)
            previous?.close()
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
            return bounds.width() to bounds.height()
        }
        @Suppress("DEPRECATION")
        val metrics = DisplayMetrics().also { getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(it) }
        return metrics.widthPixels to metrics.heightPixels
    }

    private fun consumeRequestedFrame(reader: ImageReader) {
        val image = runCatching { reader.acquireLatestImage() }.getOrNull() ?: return
        image.use { frame ->
            synchronized(frameLock) {
                if (!captureRequested) return
                val plane = frame.planes.firstOrNull() ?: return
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val paddedWidth = rowStride / pixelStride
                val fullBitmap = Bitmap.createBitmap(paddedWidth, frame.height, Bitmap.Config.ARGB_8888)
                plane.buffer.rewind()
                fullBitmap.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, frame.width, frame.height)
                if (cropped !== fullBitmap) fullBitmap.recycle()

                val scale = minOf(1f, MAX_SIDE.toFloat() / max(cropped.width, cropped.height))
                val outputBitmap = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        cropped,
                        max(1, (cropped.width * scale).roundToInt()),
                        max(1, (cropped.height * scale).roundToInt()),
                        true,
                    ).also { cropped.recycle() }
                } else cropped

                val jpegOut = ByteArrayOutputStream()
                outputBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, jpegOut)
                val outputWidth = outputBitmap.width
                val outputHeight = outputBitmap.height
                outputBitmap.recycle()
                val bytes = jpegOut.toByteArray()
                lastFrame = if (bytes.size <= MAX_JPEG_BYTES) {
                    CapturedFrame(bytes, outputWidth, outputHeight)
                } else null
                jpegOut.close()
                captureRequested = false
                sequence++
                frameLock.notifyAll()
            }
        }
    }

    private fun captureOne(timeoutMs: Long): CapturedFrame? {
        val before: Long
        synchronized(frameLock) {
            if (projection == null || imageReader == null || captureRequested) return null
            before = sequence
            captureRequested = true
            val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs)
            while (sequence == before && System.nanoTime() < deadline) {
                val remaining = deadline - System.nanoTime()
                if (remaining <= 0) break
                TimeUnit.NANOSECONDS.timedWait(frameLock, remaining)
            }
            if (sequence == before) {
                captureRequested = false
                return null
            }
            return lastFrame
        }
    }

    private fun releaseProjection(stopProjection: Boolean = true) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_READY, false).apply()
        synchronized(frameLock) {
            captureRequested = false
            lastFrame = null
            frameLock.notifyAll()
        }
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
        val active = projection
        projection = null
        if (stopProjection) runCatching { active?.stop() }
    }

    override fun onDestroy() {
        releaseProjection()
        if (::imageThread.isInitialized) imageThread.quitSafely()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    private fun buildNotification(): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_view)
        .setContentTitle(getString(com.voicepilot.agent.R.string.notification_projection))
        .setContentText("Screen frames are captured only for a voice command")
        .setOngoing(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    @Suppress("DEPRECATION")
    private fun parcelableIntent(source: Intent, key: String): Intent? =
        if (Build.VERSION.SDK_INT >= 33) source.getParcelableExtra(key, Intent::class.java) else source.getParcelableExtra(key)

    companion object {
        const val ACTION_START = "com.voicepilot.agent.capture.START"
        const val ACTION_STOP = "com.voicepilot.agent.capture.STOP"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val PREFS = "voicepilot_session"
        const val KEY_READY = "projection_ready"
        private const val CHANNEL_ID = "voicepilot_capture"
        private const val NOTIFICATION_ID = 4101
        private const val MAX_SIDE = 2400
        private const val MAX_JPEG_BYTES = 3 * 1024 * 1024
        private const val JPEG_QUALITY = 70
    }
}
