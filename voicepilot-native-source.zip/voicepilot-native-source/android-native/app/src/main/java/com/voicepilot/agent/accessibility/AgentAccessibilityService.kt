package com.voicepilot.agent.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.voicepilot.agent.R
import com.voicepilot.agent.core.ActionKind
import com.voicepilot.agent.core.ActionParser
import com.voicepilot.agent.core.AgentAction
import com.voicepilot.agent.core.AgentBus
import com.voicepilot.agent.core.AgentPreferences
import com.voicepilot.agent.core.SafetyPolicy
import java.util.UUID

class AgentAccessibilityService : AccessibilityService() {
    private data class Pending(
        val id: String,
        val action: AgentAction,
        val intent: String,
        val screenWidth: Int,
        val screenHeight: Int,
        val visibleTextSnapshot: String,
        val expiresAt: Long,
    )

    private val main = Handler(Looper.getMainLooper())
    private var receiverRegistered = false
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var pendingText: TextView? = null
    private var confirmButton: Button? = null
    private var cancelButton: Button? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var pending: Pending? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                AgentBus.ACTION_EXECUTE -> handleAction(intent)
                AgentBus.ACTION_CONFIRM_TAP -> confirmFromOverlay(intent)
                AgentBus.ACTION_CANCEL_PENDING -> cancelPending("Action cancelled.")
                AgentBus.ACTION_CONFIRM_RESULT -> applyVoiceDecision(intent)
                AgentBus.ACTION_STOP_LISTENING -> cancelPending("Cancelled. No pending action was performed.")
                AgentBus.ACTION_REFRESH_OVERLAY -> refreshOverlay()
                AgentBus.ACTION_SPEAK -> deliverFeedback(intent.getStringExtra(AgentBus.EXTRA_SPEECH).orEmpty())
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val filter = IntentFilter().apply {
            addAction(AgentBus.ACTION_EXECUTE)
            addAction(AgentBus.ACTION_CONFIRM_TAP)
            addAction(AgentBus.ACTION_CANCEL_PENDING)
            addAction(AgentBus.ACTION_CONFIRM_RESULT)
            addAction(AgentBus.ACTION_STOP_LISTENING)
            addAction(AgentBus.ACTION_REFRESH_OVERLAY)
            addAction(AgentBus.ACTION_SPEAK)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        receiverRegistered = true
        refreshOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val changed = event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event?.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        if (pending != null && changed && event?.packageName?.toString() != packageName) {
            cancelPending("The screen changed. Please review it again before taking action.")
        }
    }

    override fun onInterrupt() {
        cancelPending("Accessibility stopped. No pending action was performed.")
    }

    private fun handleAction(intent: Intent) {
        if (pending != null) cancelPending("A new action arrived. The previous request was cancelled.")
        val raw = intent.getStringExtra(AgentBus.EXTRA_ACTION_JSON)
        if (raw.isNullOrBlank()) {
            deliverFeedback("Action data is missing. No action was performed.")
            return
        }
        val voiceIntent = intent.getStringExtra(AgentBus.EXTRA_INTENT).orEmpty()
        val frameWidth = intent.getIntExtra(AgentBus.EXTRA_SCREEN_WIDTH, 0)
        val frameHeight = intent.getIntExtra(AgentBus.EXTRA_SCREEN_HEIGHT, 0)
        val action = runCatching { ActionParser.parse(raw, frameWidth, frameHeight) }.getOrElse {
            deliverFeedback("Action format invalid hai. Koi tap nahi kiya.")
            return
        }
        if (action.action == ActionKind.SPEAK) {
            deliverFeedback(action.speechResponse)
            return
        }

        val visibleText = collectVisibleText(rootInActiveWindow)
        val sensitiveContext = "$visibleText\n$voiceIntent\n${action.textPayload.orEmpty()}"
        if (action.action == ActionKind.TYPE && SafetyPolicy.isSensitiveInput(sensitiveContext)) {
            deliverFeedback("Password, payment, card, OTP ya PIN details main enter nahi kar sakta. Kripya khud review karke enter karein.")
            return
        }

        val riskContext = "$visibleText\n${action.speechResponse}"
        if (SafetyPolicy.requiresConfirmation(voiceIntent, action.textPayload, riskContext, action.action)) {
            requestConfirmation(action, voiceIntent, frameWidth, frameHeight, visibleText)
            return
        }
        execute(action, frameWidth, frameHeight) { succeeded ->
            deliverFeedback(if (succeeded) action.speechResponse else "Action complete nahi hua. Screen ko review kijiye.")
        }
    }

    private fun requestConfirmation(action: AgentAction, voiceIntent: String, width: Int, height: Int, visibleText: String) {
        cancelPending(null)
        val id = UUID.randomUUID().toString()
        val label = action.textPayload?.takeIf { it.isNotBlank() } ?: "a sensitive purchase-related action"
        val question = "Is action se kharidari ya payment ho sakti hai. Kya main ‘$label’ par tap karu? Sirf aapki clear haan par proceed hoga."
        val ticket = Pending(id, action, voiceIntent, width, height, visibleText, System.currentTimeMillis() + CONFIRM_TIMEOUT_MS)
        pending = ticket
        updateOverlayPending("Review before tapping: $label", id)
        sendBroadcast(
            Intent(AgentBus.ACTION_CONFIRM_PROMPT).setPackage(packageName)
                .putExtra(AgentBus.EXTRA_PENDING_ID, id)
                .putExtra(AgentBus.EXTRA_PROMPT, question),
        )
        main.postDelayed({
            if (pending?.id == id) cancelPending("Confirmation expired. No action was performed.")
        }, CONFIRM_TIMEOUT_MS)
    }

    private fun confirmFromOverlay(intent: Intent) {
        val id = intent.getStringExtra(AgentBus.EXTRA_PENDING_ID) ?: return
        val ticket = pending ?: return
        if (id != ticket.id || System.currentTimeMillis() > ticket.expiresAt) return
        approve(ticket)
    }

    private fun applyVoiceDecision(intent: Intent) {
        val id = intent.getStringExtra(AgentBus.EXTRA_PENDING_ID) ?: return
        val ticket = pending ?: return
        if (id != ticket.id) return
        val approved = intent.getBooleanExtra(AgentBus.EXTRA_APPROVED, false)
        if (approved && System.currentTimeMillis() <= ticket.expiresAt) approve(ticket)
        else cancelPending("Confirmation nahi mili. Koi action nahi kiya.")
    }

    private fun approve(ticket: Pending) {
        if (pending?.id != ticket.id) return
        if (overlay == null || !Settings.canDrawOverlays(this)) {
            cancelPending("Confirmation controls unavailable. No action was performed.")
            return
        }
        val currentText = collectVisibleText(rootInActiveWindow)
        if (currentText != ticket.visibleTextSnapshot ||
            findClickableByLabel(rootInActiveWindow, ticket.action.textPayload.orEmpty()) == null
        ) {
            cancelPending("The screen or target changed. No action was performed.")
            return
        }
        pending = null
        updateOverlayPending(null, null)
        sendBroadcast(
            Intent(AgentBus.ACTION_CONFIRM_RESULT).setPackage(packageName)
                .putExtra(AgentBus.EXTRA_PENDING_ID, ticket.id)
                .putExtra(AgentBus.EXTRA_APPROVED, true),
        )
        execute(ticket.action, ticket.screenWidth, ticket.screenHeight, requireSemanticTarget = true) { succeeded ->
            deliverFeedback(if (succeeded) ticket.action.speechResponse else "The confirmed target is no longer available. No tap was performed.")
        }
    }

    private fun cancelPending(message: String?) {
        val prior = pending
        pending = null
        updateOverlayPending(null, null)
        prior?.let {
            sendBroadcast(
                Intent(AgentBus.ACTION_CONFIRM_RESULT).setPackage(packageName)
                    .putExtra(AgentBus.EXTRA_PENDING_ID, it.id)
                    .putExtra(AgentBus.EXTRA_APPROVED, false)
                    .putExtra(AgentBus.EXTRA_SPEECH, message.orEmpty()),
            )
        }
    }

    private fun execute(
        action: AgentAction,
        frameWidth: Int,
        frameHeight: Int,
        requireSemanticTarget: Boolean = false,
        onComplete: (Boolean) -> Unit,
    ) {
        val point = action.coordinates
        val display = displaySize()
        val mappedX = point?.let { (it.x.toDouble() * display.first / frameWidth.coerceAtLeast(1)).toInt().coerceIn(0, display.first - 1) }
        val mappedY = point?.let { (it.y.toDouble() * display.second / frameHeight.coerceAtLeast(1)).toInt().coerceIn(0, display.second - 1) }

        when (action.action) {
            ActionKind.CLICK -> {
                val semantic = action.textPayload?.let { findClickableByLabel(rootInActiveWindow, it) }
                val clicked = semantic?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                if (clicked) onComplete(true)
                else if (requireSemanticTarget || mappedX == null || mappedY == null) onComplete(false)
                else dispatchTap(mappedX, mappedY, onComplete)
            }
            ActionKind.TYPE -> {
                val editable = findEditableAt(rootInActiveWindow, mappedX ?: -1, mappedY ?: -1)
                if (editable == null) {
                    onComplete(false)
                    return
                }
                editable.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, action.textPayload)
                }
                onComplete(editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args))
            }
            ActionKind.SWIPE -> {
                if (mappedX != null && mappedY != null) dispatchSwipe(display.first / 2, display.second / 2, mappedX, mappedY, onComplete)
                else onComplete(false)
            }
            ActionKind.SPEAK -> {
                deliverFeedback(action.speechResponse)
                onComplete(true)
            }
        }
    }

    private fun findClickableByLabel(root: AccessibilityNodeInfo?, label: String): AccessibilityNodeInfo? {
        if (root == null || label.isBlank()) return null
        val normalized = label.trim().lowercase()
        fun visit(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
            if (depth > MAX_TREE_DEPTH) return null
            val labels = sequenceOf(node.text, node.contentDescription)
                .filterNotNull().map { it.toString().trim().lowercase() }
            if (node.isVisibleToUser && labels.any { it == normalized }) {
                var current: AccessibilityNodeInfo? = node
                var hops = 0
                while (current != null && hops++ < 8) {
                    if (current.isVisibleToUser && current.isClickable && current.isEnabled) return current
                    current = current.parent
                }
            }
            for (index in 0 until node.childCount) {
                val child = node.getChild(index) ?: continue
                val found = visit(child, depth + 1)
                if (found != null) return found
            }
            return null
        }
        return visit(root, 0)
    }

    private fun findEditableAt(root: AccessibilityNodeInfo?, x: Int, y: Int): AccessibilityNodeInfo? {
        if (root == null) return null
        fun visit(node: AccessibilityNodeInfo, depth: Int): AccessibilityNodeInfo? {
            if (depth > MAX_TREE_DEPTH) return null
            for (index in 0 until node.childCount) {
                val child = node.getChild(index) ?: continue
                val found = visit(child, depth + 1)
                if (found != null) return found
            }
            if (node.isVisibleToUser && node.isEditable && node.isEnabled) {
                val bounds = Rect().also(node::getBoundsInScreen)
                if (bounds.contains(x, y)) return node
            }
            return null
        }
        return visit(root, 0)
    }

    private fun collectVisibleText(root: AccessibilityNodeInfo?): String {
        if (root == null) return ""
        val values = ArrayList<String>()
        fun visit(node: AccessibilityNodeInfo, depth: Int) {
            if (depth > MAX_TREE_DEPTH || values.size >= MAX_VISIBLE_TEXTS || !node.isVisibleToUser) return
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(values::add)
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(values::add)
            for (index in 0 until node.childCount) {
                val child = node.getChild(index) ?: continue
                visit(child, depth + 1)
                if (values.size >= MAX_VISIBLE_TEXTS) break
            }
        }
        visit(root, 0)
        return values.joinToString(" ").take(12_000)
    }

    private fun dispatchTap(x: Int, y: Int, onComplete: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) = onComplete(true)
            override fun onCancelled(gestureDescription: GestureDescription) = onComplete(false)
        }, main)
        if (!accepted) onComplete(false)
    }

    private fun dispatchSwipe(startX: Int, startY: Int, endX: Int, endY: Int, onComplete: (Boolean) -> Unit) {
        val path = Path().apply {
            moveTo(startX.toFloat(), startY.toFloat())
            lineTo(endX.toFloat(), endY.toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) = onComplete(true)
            override fun onCancelled(gestureDescription: GestureDescription) = onComplete(false)
        }, main)
        if (!accepted) onComplete(false)
    }

    private fun displaySize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val rect = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
            return rect.width() to rect.height()
        }
        @Suppress("DEPRECATION")
        val metrics = resources.displayMetrics
        return metrics.widthPixels to metrics.heightPixels
    }

    private fun refreshOverlay() {
        if (!AgentPreferences.overlayEnabled(this) || !Settings.canDrawOverlays(this)) {
            removeOverlay()
            return
        }
        if (overlay == null) createOverlay()
        updateOverlayPending(pending?.let { "Review before tapping: ${it.action.textPayload ?: "sensitive action"}" }, pending?.id)
    }

    private fun createOverlay() {
        val wm = windowManager ?: return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(getColor(R.color.ink))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(2), getColor(R.color.jade))
            }
            elevation = dp(8).toFloat()
        }
        val label = TextView(this).apply {
            text = "VoicePilot · ready"
            textSize = 13f
            setTextColor(getColor(R.color.white))
            contentDescription = "VoicePilot agent status"
        }
        panel.addView(label)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(widgetButton("Back") { performGlobalAction(GLOBAL_ACTION_BACK) })
        controls.addView(widgetButton("Stop") {
            cancelPending("Cancelled. No pending action was performed.")
            sendBroadcast(Intent(AgentBus.ACTION_STOP_LISTENING).setPackage(packageName))
        })
        panel.addView(controls)
        pendingText = TextView(this).apply {
            textSize = 13f
            setTextColor(getColor(R.color.saffron))
            visibility = View.GONE
            setPadding(0, dp(6), 0, dp(4))
        }
        panel.addView(pendingText)
        val decisionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        confirmButton = widgetButton("Confirm") {
            val id = pending?.id ?: return@widgetButton
            sendBroadcast(Intent(AgentBus.ACTION_CONFIRM_TAP).setPackage(packageName).putExtra(AgentBus.EXTRA_PENDING_ID, id))
        }.also(decisionRow::addView)
        cancelButton = widgetButton("Cancel") {
            sendBroadcast(Intent(AgentBus.ACTION_CANCEL_PENDING).setPackage(packageName))
        }.also(decisionRow::addView)
        panel.addView(decisionRow)
        panel.tag = decisionRow

        val params = WindowManager.LayoutParams(
            dp(292),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(100)
        }
        try {
            wm.addView(panel, params)
            overlay = panel
            overlayParams = params
        } catch (_: Exception) {
            overlay = null
            overlayParams = null
        }
    }

    private fun updateOverlayPending(text: String?, id: String?) {
        pendingText?.text = text.orEmpty()
        pendingText?.visibility = if (text.isNullOrBlank()) View.GONE else View.VISIBLE
        confirmButton?.visibility = if (id == null) View.GONE else View.VISIBLE
        cancelButton?.visibility = if (id == null) View.GONE else View.VISIBLE
        val decisionRow = overlay?.tag as? LinearLayout
        decisionRow?.visibility = if (id == null) View.GONE else View.VISIBLE
    }

    private fun widgetButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 12f
        setPadding(dp(4), 0, dp(4), 0)
        minHeight = dp(38)
        minWidth = dp(70)
        setOnClickListener { onClick() }
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { windowManager?.removeView(it) } }
        overlay = null
        pendingText = null
        confirmButton = null
        cancelButton = null
        overlayParams = null
    }

    private fun deliverFeedback(message: String) {
        if (message.isNotBlank()) {
            sendBroadcast(
                Intent(AgentBus.ACTION_AGENT_RESULT).setPackage(packageName)
                    .putExtra(AgentBus.EXTRA_SPEECH, message.take(320)),
            )
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        cancelPending(null)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(receiver) }
        super.onDestroy()
    }

    companion object {
        private const val CONFIRM_TIMEOUT_MS = 25_000L
        private const val MAX_TREE_DEPTH = 30
        private const val MAX_VISIBLE_TEXTS = 320
    }
}
