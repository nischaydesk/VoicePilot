package com.voicepilot.agent.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class ActionParserTest {
    @Test fun parsesExactClickSchema() {
        val action = ActionParser.parse(
            """{"action":"CLICK","coordinates":{"x":540,"y":320},"text_payload":"Search","speech_response":"Done"}""",
            1080,
            2400,
        )
        assertEquals(ActionKind.CLICK, action.action)
        assertEquals(ScreenPoint(540, 320), action.coordinates)
        assertEquals("Search", action.textPayload)
    }

    @Test fun parsesSpeakWithNullableCoordinates() {
        val action = ActionParser.parse(
            """{"action":"SPEAK","coordinates":null,"text_payload":null,"speech_response":"Ji"}""",
            1080,
            2400,
        )
        assertNull(action.coordinates)
        assertNull(action.textPayload)
    }

    @Test fun validatesTypeAndSwipePayloadRules() {
        val type = ActionParser.parse(
            """{"action":"TYPE","coordinates":{"x":10,"y":20},"text_payload":"Banarasi Saree","speech_response":"Searching"}""",
            100,
            100,
        )
        assertEquals(ActionKind.TYPE, type.action)
        assertEquals("Banarasi Saree", type.textPayload)
        val swipe = ActionParser.parse(
            """{"action":"SWIPE","coordinates":{"x":10,"y":20},"text_payload":null,"speech_response":"Scrolling"}""",
            100,
            100,
        )
        assertEquals(ActionKind.SWIPE, swipe.action)
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"SWIPE","coordinates":{"x":10,"y":20},"text_payload":"unexpected","speech_response":"Scrolling"}""",
                100,
                100,
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"CLICK","coordinates":{"x":10,"y":20},"text_payload":null,"speech_response":"Tap"}""",
                100,
                100,
            )
        }
    }

    @Test fun rejectsOutOfBoundsAndUnknownFields() {
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"CLICK","coordinates":{"x":1080,"y":2},"text_payload":null,"speech_response":"x"}""",
                1080,
                2400,
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"CLICK","coordinates":{"x":2,"y":2},"text_payload":null,"speech_response":"x","extra":true}""",
                1080,
                2400,
            )
        }
    }

    @Test fun rejectsFloatCoordinatesAndMissingActionFields() {
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"CLICK","coordinates":{"x":1.5,"y":2},"text_payload":null,"speech_response":"x"}""",
                10,
                10,
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse("""{"action":"TYPE","coordinates":null,"text_payload":"hi","speech_response":"x"}""", 10, 10)
        }
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse("""{"action":"CLICK","coordinates":{"x":1.0,"y":2},"text_payload":"Search","speech_response":"x"}""", 10, 10)
        }
    }

    @Test fun rejectsDuplicateKeysAtBothSchemaLevels() {
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"CLICK","action":"SPEAK","coordinates":{"x":1,"y":2},"text_payload":"Search","speech_response":"x"}""",
                10,
                10,
            )
        }
        assertThrows(IllegalArgumentException::class.java) {
            ActionParser.parse(
                """{"action":"CLICK","coordinates":{"x":1,"x":2,"y":2},"text_payload":"Search","speech_response":"x"}""",
                10,
                10,
            )
        }
    }

    @Test fun asksForConfirmationAndRejectsAmbiguousConfirmation() {
        assertEquals(true, SafetyPolicy.requiresConfirmation("please checkout", "Pay now", "", ActionKind.CLICK))
        assertEquals(true, SafetyPolicy.requiresConfirmation("Open details", "Continue", "This is a sensitive purchase action.", ActionKind.CLICK))
        assertEquals(true, SafetyPolicy.requiresConfirmation("Reserve a booking", "Confirm booking", "", ActionKind.CLICK))
        assertEquals(true, SafetyPolicy.requiresConfirmation("Send money transfer", "Continue", "", ActionKind.CLICK))
        assertEquals(true, SafetyPolicy.isSensitiveInput("Enter your password here"))
        assertEquals(true, SafetyPolicy.isAffirmativeConfirmation("haan confirm karo"))
        assertEquals(true, SafetyPolicy.isAffirmativeConfirmation("हाँ confirm करो"))
        assertEquals(false, SafetyPolicy.isAffirmativeConfirmation("haan, nahi karo"))
        assertEquals(false, SafetyPolicy.isAffirmativeConfirmation("maybe yes"))
        assertEquals(false, SafetyPolicy.isAffirmativeConfirmation("yes, but wait"))
        assertEquals(false, SafetyPolicy.isAffirmativeConfirmation("maybe"))
    }
}
