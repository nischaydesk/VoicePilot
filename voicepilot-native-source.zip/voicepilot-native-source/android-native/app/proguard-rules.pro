# Manifest-declared activities and services are kept by the Android Gradle plugin.
# JSONObject use is direct (no reflective model serialization); add narrowly scoped rules here only if release testing proves they are needed.
