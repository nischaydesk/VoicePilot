# VoicePilot Android app

This standalone Kotlin Android app is the requested APK source project. It is separate from the repository's Expo starter; open `android-native/` in Android Studio.

## Requirements and build

Install Android Studio (or Android SDK command-line tools) with Android SDK Platform 35 and Build Tools 35, plus JDK 17+. From this directory run:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`. Release signing is not configured. The included Gradle wrapper downloads Gradle 8.11.1. The app targets API 35 and supports API 26+.

## First-run setup

1. Deploy `../vision-backend/` behind HTTPS and configure the Gemini key and bearer token as server-side secrets.
2. Open VoicePilot, enter the backend HTTPS base URL and the matching bearer token, then save. The token is encrypted with AndroidX Security Crypto; query strings and fragments are rejected.
3. Enable **VoicePilot action assistance** in Android Accessibility Settings. Android requires the user to enable this service; `BIND_ACCESSIBILITY_SERVICE` is a service binding permission, not a runtime prompt.
4. Grant the floating-widget permission in Settings. The overlay offers Back and Stop, and displays one-use Confirm/Cancel controls for sensitive taps.
5. Start a MediaProjection capture session and grant Android's system consent. Consent is required again for a new session.
6. Grant microphone and notification permission and start listening from the visible app. Hindi (`hi-IN`) recognition is user-started and runs in a foreground service with a persistent Stop notification; it is not an always-on hotword listener.

## Safety, privacy, and platform limits

Sensitive checkout/payment/order-related taps are paused for Hindi TTS plus an exact-target confirmation card. The card expires after 25 seconds. A fresh screen-text snapshot and exact, visible accessibility label must still match at approval; otherwise the action is cancelled. Sensitive clicks never fall back to coordinates. Low-risk coordinate gestures remain a fallback when semantic nodes are unavailable. Text entry only targets a visible editable node whose bounds contain the requested point, and password/card/CVV/OTP/PIN/bank details are refused based on current accessible text, intent and payload.

A screenshot and recognized voice intent are sent to the configured backend only after a command. Android does not persist the screenshot or transcript; keep the endpoint HTTPS and review provider data-retention terms. The backend sample does not provide rate limiting or abuse monitoring. Restrict ingress, rotate credentials and put it behind a gateway before real deployment.

`SpeechRecognizer` is provider/device-dependent, is not intended for unrestricted continuous recognition, and may send audio to a remote recognition service. Accessibility trees can omit or mislabel third-party controls, and OEM MediaProjection/overlay behavior varies. This is a source project, not a Play Store policy approval or production signing configuration. Google Play distribution requires its separate accessibility disclosure and policy review.

The Sandbox self-tests cover the backend JSON contract and manifest declarations. Its APK build could not be verified because the available Java runtime lacks `javac` and no Android SDK is installed. Run the Gradle commands above from a compatible JDK/SDK workstation and test screen capture, gestures, overlay and speech on a real device before deployment.
