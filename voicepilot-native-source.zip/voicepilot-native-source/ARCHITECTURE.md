# VoicePilot: Android Action Agent architecture

## Components and data flow

The native Android project lives in `android-native/` and is independent of the preserved Expo starter. `MainActivity` owns setup and permission handoffs. The user enables Android Accessibility and the floating overlay in Settings, enters an HTTPS backend URL and bearer token, grants MediaProjection consent, and explicitly starts the microphone service from the visible app. The floating widget offers Back, Stop, Cancel and one-use Confirm controls.

A Hindi/Hinglish transcript from `SpeechRecognizer` is accepted only during that user-started session. `VoiceCommandService` runs as a visible microphone foreground service and re-arms bounded recognition requests while the user keeps it active; it is not an OS hotword detector. For each command, it asks the projection service for one JPEG frame, then sends the transcript and image to `POST /v1/decide`. The backend validates the request, sends image and intent to Gemini with schema-constrained JSON output, validates the response and returns one proposal. The backend has no app-control capability. Android parses the response again; `AgentAccessibilityService` alone may act. A single TTS channel announces the action only after the accessibility action reports success, or reports a failure without claiming success.

## Action contract

The API returns exactly four fields:

```json
{
  "action": "TYPE",
  "coordinates": { "x": 540, "y": 320 },
  "text_payload": "Banarasi Saree",
  "speech_response": "Saree search kar di hai, pasand kijiye"
}
```

`CLICK`, `TYPE`, and `SWIPE` require in-screen integer pixel coordinates. For `CLICK`, `text_payload` is the exact visible target label; for `TYPE`, it is the requested text and coordinates identify the input field. `SWIPE` starts at screen center and ends at the returned point. `SPEAK` requires null coordinates and payload. Payloads are at most 240 characters and speech is at most 320. The API and client reject unknown keys, invalid action names, malformed values, duplicate JSON keys and out-of-range coordinates.

The accessibility service prefers an exact, visible `text` or `contentDescription` label and uses `AccessibilityNodeInfo.ACTION_CLICK`; coordinate gestures are a fallback only for non-sensitive clicks. Text injection requires an enabled, visible editable node whose screen bounds contain the model coordinate; there is no fallback to an unrelated field. Swipes and coordinate taps use `dispatchGesture`, and navigation Back uses `performGlobalAction`.

## Sensitive-action confirmation

Checkout, payment, purchase, booking, money transfer, order-placement and other purchase-risk phrases in the voice intent, target label, model warning or visible accessibility text pause the automatic path. Android speaks a question, names the proposed target in a visible confirmation card and waits for a clear spoken affirmative or explicit Confirm tap. The ticket is one-use and expires after 25 seconds. It is invalidated on external window/content changes, a new action, Stop, Cancel, service interruption or timeout. Before approval is honored, Android compares a fresh visible-text snapshot and resolves the exact target label again; sensitive taps require a current semantic click and never use coordinate fallback. Ambiguity, missing controls, stale screen, missing target, service loss, refusal, or policy failure does not tap. The app refuses to type into password, card, CVV, OTP, PIN and similar fields based on visible screen text, intent and payload.

This remains a best-effort policy layer, not proof that every inaccessible canvas or misleading third-party label is classifiable perfectly. The person must review the current app screen and exact target.

## Privacy and Android platform behavior

Screenshot pixels and recognized text leave the device for the configured backend only after a user voice command. They are kept in memory for processing, not written to local files or included in server logs. Android stores the API bearer token using AndroidX Security Crypto. Use HTTPS, keep the Gemini key server-side, generate a high-entropy client token, restrict ingress, rotate credentials and review provider retention terms. The sample server does not include rate limiting, durable audit storage or abuse monitoring.

MediaProjection requires system user consent for each capture session. On Android 14+, the service declares `mediaProjection` and the matching foreground-service permission. One virtual display is created per consent session and resized as needed. The user can stop the session from the app or system projection controls.

The microphone service starts only after an explicit button press and displays a persistent Stop notification. `SpeechRecognizer` is documented as not intended for continuous recognition, and recognizer implementations may send audio to remote services. This app re-arms bounded recognition requests during the foreground session; language support, connectivity, power use and behavior depend on the device. If capture, recognition or action execution fails, the app reports failure and does not claim the action succeeded.

Android describes AccessibilityService as intended to assist users with disabilities. The user must enable it in Settings and receive clear disclosure. Google Play distribution requires separate policy review and current Accessibility API disclosures; this project does not claim Play approval.

## Build and run

Install Android Studio or command-line Android SDK with Platform 35 and Build Tools 35, plus JDK 17+. From `android-native/`, run `./gradlew testDebugUnitTest` and `./gradlew assembleDebug`; the debug APK output is `app/build/outputs/apk/debug/app-debug.apk`. Release signing is not configured. The repo includes Gradle wrapper 8.11.1. From `vision-backend/`, set `GEMINI_API_KEY` and `API_BEARER_TOKEN` via the server's secret environment, then run `npm start` behind HTTPS. Configure that URL and token in the app. `STUB_VISION=1` is local-test-only and returns a safe SPEAK response.

From the repository root, `./scripts/self-test.sh` runs backend tests and checks Android manifest permissions/service declarations. Android JVM tests are included, but device-specific capture, gesture, overlay, OEM and recognizer behavior require real-device verification. Sandbox APK build verification was not completed because the environment has no Java compiler or Android SDK; the Gradle wrapper and Android Studio project are ready for a compatible workstation.

## Platform references

[1]: https://developer.android.com/media/grow/media-projection "Android Media projection guide"
[2]: https://developer.android.com/develop/background-work/services/fgs/service-types "Android foreground service types"
[3]: https://developer.android.com/reference/android/speech/SpeechRecognizer "Android SpeechRecognizer reference"
[4]: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService "Android AccessibilityService reference"
[5]: https://ai.google.dev/api/generate-content "Gemini generate content API"
[6]: https://ai.google.dev/gemini-api/docs/image-understanding "Gemini image understanding"
