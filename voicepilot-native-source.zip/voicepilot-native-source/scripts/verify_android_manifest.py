#!/usr/bin/env python3
"""Validate the native app's critical permission and service declarations."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "android-native/app/src/main/AndroidManifest.xml"
ACCESSIBILITY = ROOT / "android-native/app/src/main/res/xml/accessibility_service_config.xml"
ANDROID = "{http://schemas.android.com/apk/res/android}"


def fail(message: str) -> None:
    print(f"FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)

try:
    manifest = ET.parse(MANIFEST).getroot()
    accessibility = ET.parse(ACCESSIBILITY).getroot()
except (ET.ParseError, OSError) as error:
    fail(f"manifest XML could not be parsed: {error}")

permissions = {element.get(ANDROID + "name") for element in manifest.findall("uses-permission")}
required = {
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
    "android.permission.SYSTEM_ALERT_WINDOW",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION",
    "android.permission.FOREGROUND_SERVICE_MICROPHONE",
}
missing = required - permissions
if missing:
    fail("missing uses-permission entries: " + ", ".join(sorted(missing)))

services = {service.get(ANDROID + "name"): service for service in manifest.findall("./application/service")}
accessibility_service = services.get(".accessibility.AgentAccessibilityService")
if accessibility_service is None:
    fail("AccessibilityService declaration is missing")
if accessibility_service.get(ANDROID + "permission") != "android.permission.BIND_ACCESSIBILITY_SERVICE":
    fail("service must be protected by android.permission.BIND_ACCESSIBILITY_SERVICE")
if accessibility_service.get(ANDROID + "exported") != "true":
    fail("system-discoverable AccessibilityService must be exported=true and permission-protected")
metadata = accessibility_service.find("meta-data")
if metadata is None or metadata.get(ANDROID + "resource") != "@xml/accessibility_service_config":
    fail("AccessibilityService metadata must reference its configuration XML")
if accessibility_service.find("intent-filter/action") is None or accessibility_service.find("intent-filter/action").get(ANDROID + "name") != "android.accessibilityservice.AccessibilityService":
    fail("AccessibilityService intent action is missing")

if accessibility.get(ANDROID + "canPerformGestures") != "true":
    fail("canPerformGestures must be true")
if accessibility.get(ANDROID + "canRetrieveWindowContent") != "true":
    fail("canRetrieveWindowContent must be true")

capture = services.get(".capture.ScreenCaptureService")
voice = services.get(".voice.VoiceCommandService")
if capture is None or capture.get(ANDROID + "foregroundServiceType") != "mediaProjection":
    fail("MediaProjection foreground service type declaration is missing")
if voice is None or voice.get(ANDROID + "foregroundServiceType") != "microphone":
    fail("microphone foreground service type declaration is missing")

print("PASS: manifest permissions, BIND_ACCESSIBILITY_SERVICE, metadata, gestures, and foreground-service types")
