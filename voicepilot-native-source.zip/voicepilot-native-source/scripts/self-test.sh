#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 "$ROOT/scripts/verify_android_manifest.py"
(
  cd "$ROOT/vision-backend"
  npm test
)
