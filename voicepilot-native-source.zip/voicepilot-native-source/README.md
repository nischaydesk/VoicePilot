# VoicePilot native Android source bundle

This archive contains the requested standalone Kotlin Android Studio/Gradle app, Node.js Gemini Vision decision API, architecture notes, and source self-tests. No API keys, build artifacts, Gradle caches, or Expo starter dependencies are included.

## Structure

- `android-native/` — complete Android Gradle project with wrapper, Kotlin AccessibilityService, overlay, consent-based MediaProjection service, user-started Hindi/Hinglish voice service, TTS, strict action parser, and sensitive-action confirmation gate.
- `vision-backend/` — standalone Node.js 20+ API with Gemini multimodal decision logic, bearer-token auth, payload/time limits, strict four-field JSON validation, safe stub mode, and tests.
- `ARCHITECTURE.md` — data flow, action contract, privacy, safety gate, permissions, platform limits, and deployment guidance.
- `scripts/` — backend/manifest self-test and `BIND_ACCESSIBILITY_SERVICE` manifest checker.

## Build

Install JDK 17+ and Android SDK Platform/Build Tools 35, then run:

```bash
cd android-native
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

The debug APK path is `android-native/app/build/outputs/apk/debug/app-debug.apk`. Release signing is not configured. This source was not compiled in the producing Sandbox because it has no `javac` compiler or Android SDK; build and test on Android Studio or a compatible workstation.

## Backend

Set `GEMINI_API_KEY` and a high-entropy `API_BEARER_TOKEN` in the server environment and run `npm start` from `vision-backend/` behind HTTPS. Enter that HTTPS URL and matching bearer token in the app. Never put the Gemini key in the Android client. `STUB_VISION=1` disables authentication and is for local tests only.

Run `./scripts/self-test.sh` from the archive root for backend schema/API tests and manifest checks. Android parser/policy JVM tests are included; device-level projection, Accessibility, overlay and speech behavior still require real-device verification.
