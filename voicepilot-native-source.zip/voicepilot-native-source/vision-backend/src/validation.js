const ACTIONS = new Set(['CLICK', 'TYPE', 'SWIPE', 'SPEAK']);
const MODEL_KEYS = new Set(['action', 'coordinates', 'text_payload', 'speech_response']);
const REQUEST_KEYS = new Set(['intent', 'image_base64', 'mime_type', 'screen_width', 'screen_height']);

export const SAFE_SPEAK = Object.freeze({
  action: 'SPEAK',
  coordinates: null,
  text_payload: null,
  speech_response: 'I could not safely determine the next action. Please review the screen and try again.'
});

function hasExactKeys(value, expected) {
  const keys = Object.keys(value);
  return keys.length === expected.size && keys.every((key) => expected.has(key));
}

function isSafeInteger(value) {
  return Number.isSafeInteger(value);
}

function containsDuplicateObjectKeys(source) {
  let index = 0;
  let duplicate = false;
  const skipWhitespace = () => { while (/\s/.test(source[index] ?? '')) index += 1; };
  const readString = () => {
    if (source[index] !== '"') return null;
    const start = index++;
    while (index < source.length) {
      const char = source[index++];
      if (char === '\\') index += 1;
      else if (char === '"') {
        try { return JSON.parse(source.slice(start, index)); } catch { return null; }
      }
    }
    return null;
  };
  const readValue = () => {
    skipWhitespace();
    const char = source[index];
    if (char === '{') {
      index += 1;
      skipWhitespace();
      const keys = new Set();
      if (source[index] === '}') { index += 1; return; }
      while (index < source.length) {
        skipWhitespace();
        const key = readString();
        if (key === null) return;
        if (keys.has(key)) duplicate = true;
        keys.add(key);
        skipWhitespace();
        if (source[index] !== ':') return;
        index += 1;
        readValue();
        skipWhitespace();
        if (source[index] === ',') { index += 1; continue; }
        if (source[index] === '}') { index += 1; return; }
        return;
      }
      return;
    }
    if (char === '[') {
      index += 1;
      skipWhitespace();
      if (source[index] === ']') { index += 1; return; }
      while (index < source.length) {
        const before = index;
        readValue();
        if (index === before) return;
        skipWhitespace();
        if (source[index] === ',') { index += 1; continue; }
        if (source[index] === ']') { index += 1; return; }
        return;
      }
      return;
    }
    if (char === '"') { readString(); return; }
    const start = index;
    while (index < source.length && !/[\s,\]}]/.test(source[index])) index += 1;
    if (index === start) index += 1;
  };
  readValue();
  return duplicate;
}

function isCanonicalBase64(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length % 4 !== 0) return false;
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) return false;
  try {
    return Buffer.from(value, 'base64').toString('base64') === value;
  } catch {
    return false;
  }
}

export function validateDecisionRequest(input, limits = {}) {
  const maxIntentChars = limits.maxIntentChars ?? 1200;
  const maxImageBase64Chars = limits.maxImageBase64Chars ?? 11_000_000;
  if (!input || typeof input !== 'object' || Array.isArray(input) || !hasExactKeys(input, REQUEST_KEYS)) {
    return { ok: false, error: 'request_schema_invalid' };
  }
  const { intent, image_base64: imageBase64, mime_type: mimeType, screen_width: width, screen_height: height } = input;
  if (typeof intent !== 'string' || intent.trim().length === 0 || intent.length > maxIntentChars) {
    return { ok: false, error: 'intent_invalid' };
  }
  if (typeof mimeType !== 'string' || mimeType !== 'image/jpeg') {
    return { ok: false, error: 'mime_type_invalid' };
  }
  if (!isSafeInteger(width) || !isSafeInteger(height) || width < 1 || height < 1 || width > 10000 || height > 10000) {
    return { ok: false, error: 'screen_dimensions_invalid' };
  }
  if (typeof imageBase64 !== 'string' || imageBase64.length > maxImageBase64Chars || !isCanonicalBase64(imageBase64)) {
    return { ok: false, error: 'image_base64_invalid' };
  }
  const image = Buffer.from(imageBase64, 'base64');
  if (image.length < 4 || image[0] !== 0xff || image[1] !== 0xd8 || image[2] !== 0xff) {
    return { ok: false, error: 'jpeg_invalid' };
  }
  return { ok: true, value: { intent, imageBase64, mimeType, width, height } };
}

export function validateModelDecision(input, { width, height } = {}) {
  if (!input || typeof input !== 'object' || Array.isArray(input) || !hasExactKeys(input, MODEL_KEYS)) {
    return { ok: false, error: 'model_schema_invalid' };
  }
  const { action, coordinates, text_payload: textPayload, speech_response: speechResponse } = input;
  if (!ACTIONS.has(action) || typeof speechResponse !== 'string' || speechResponse.length > 320) {
    return { ok: false, error: 'model_fields_invalid' };
  }
  if (!(textPayload === null || (typeof textPayload === 'string' && textPayload.length <= 240))) {
    return { ok: false, error: 'model_text_payload_invalid' };
  }
  if (coordinates !== null) {
    if (!coordinates || typeof coordinates !== 'object' || Array.isArray(coordinates) ||
        Object.keys(coordinates).length !== 2 || !Object.hasOwn(coordinates, 'x') || !Object.hasOwn(coordinates, 'y') ||
        !isSafeInteger(coordinates.x) || !isSafeInteger(coordinates.y) ||
        !Number.isSafeInteger(width) || !Number.isSafeInteger(height) ||
        coordinates.x < 0 || coordinates.y < 0 || coordinates.x >= width || coordinates.y >= height) {
      return { ok: false, error: 'model_coordinates_invalid' };
    }
  }
  if ((action === 'CLICK' || action === 'TYPE' || action === 'SWIPE') && coordinates === null) return { ok: false, error: 'model_coordinates_required' };
  if (action === 'SPEAK' && coordinates !== null) return { ok: false, error: 'model_coordinates_forbidden' };
  if (action === 'CLICK' && (textPayload === null || textPayload.length === 0)) return { ok: false, error: 'model_click_label_required' };
  if (action === 'TYPE' && (textPayload === null || textPayload.length === 0)) return { ok: false, error: 'model_type_payload_required' };
  if ((action === 'SWIPE' || action === 'SPEAK') && textPayload !== null) return { ok: false, error: 'model_payload_forbidden' };
  return { ok: true, value: { action, coordinates, text_payload: textPayload, speech_response: speechResponse } };
}

const HIGH_RISK_TERMS = /(?:checkout|check\s*out|payment|pay\s*(?:now|for)|purchase|buy\b|order\s+placement|place\s+(?:an?\s+|the\s+)?order|confirm\s+(?:the\s+)?order|final\s+(?:submit|click|confirmation)|submit\s+(?:the\s+)?order|book(?:ing)?\b|money\s+transfer|transfer\s+money|send\s+money|complete\s+(?:the\s+)?(?:order|purchase)|payee|ऑर्डर\s*(?:करें|प्लेस)|भुगतान|अभी\s*खरीद|खरीदें|खरीदारी)/i;

export function markHighRiskClickForConfirmation(decision) {
  if (decision.action !== 'CLICK') return decision;
  const searchable = `${decision.speech_response}\n${decision.text_payload ?? ''}`;
  if (!HIGH_RISK_TERMS.test(searchable)) return decision;
  return {
    ...decision,
    speech_response: 'This is a sensitive purchase action. Please confirm it on the device before proceeding.'
  };
}

export function parseAndValidateModelText(text, dimensions) {
  if (typeof text !== 'string' || text.length > 20000) return { ok: false, error: 'model_text_invalid' };
  const withoutFence = text.replace(/^\s*```(?:json)?\s*/i, '').replace(/\s*```\s*$/, '').trim();
  if (containsDuplicateObjectKeys(withoutFence)) return { ok: false, error: 'model_json_duplicate_key' };
  let parsed;
  try {
    parsed = JSON.parse(withoutFence);
  } catch {
    return { ok: false, error: 'model_json_invalid' };
  }
  const checked = validateModelDecision(parsed, dimensions);
  return checked.ok ? { ok: true, value: markHighRiskClickForConfirmation(checked.value) } : checked;
}
