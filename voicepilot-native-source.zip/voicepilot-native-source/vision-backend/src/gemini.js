import { buildUserPrompt, SYSTEM_INSTRUCTION } from './prompt.js';

export function createGeminiClient({ apiKey, model, fetchImpl = globalThis.fetch, timeoutMs = 12000 }) {
  if (typeof fetchImpl !== 'function') throw new Error('fetch_unavailable');
  return {
    async decide({ intent, imageBase64, width, height }) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
        const response = await fetchImpl(endpoint, {
          method: 'POST',
          signal: controller.signal,
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
            contents: [{ role: 'user', parts: [
              { text: buildUserPrompt({ intent, width, height }) },
              { inlineData: { mimeType: 'image/jpeg', data: imageBase64 } }
            ] }],
            generationConfig: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: 'OBJECT',
                properties: {
                  action: { type: 'STRING', enum: ['CLICK', 'TYPE', 'SWIPE', 'SPEAK'] },
                  coordinates: {
                    type: 'OBJECT', nullable: true,
                    properties: { x: { type: 'INTEGER' }, y: { type: 'INTEGER' } },
                    required: ['x', 'y']
                  },
                  text_payload: { type: 'STRING', nullable: true, maxLength: 240 },
                  speech_response: { type: 'STRING', maxLength: 320 }
                },
                required: ['action', 'coordinates', 'text_payload', 'speech_response']
              },
              temperature: 0.1
            }
          })
        });
        if (!response.ok) throw new Error(`gemini_http_${response.status}`);
        const payload = await response.json();
        const text = payload?.candidates?.[0]?.content?.parts?.map((part) => part?.text ?? '').join('');
        if (!text) throw new Error('gemini_empty_response');
        return text;
      } finally {
        clearTimeout(timer);
      }
    }
  };
}

export function createStubVision() {
  return {
    async decide() {
      return JSON.stringify({
        action: 'SPEAK',
        coordinates: null,
        text_payload: null,
        speech_response: 'Stub vision is enabled; no action was executed.'
      });
    }
  };
}
