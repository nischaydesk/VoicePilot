import http from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { createGeminiClient, createStubVision } from './gemini.js';
import { SAFE_SPEAK, parseAndValidateModelText, validateDecisionRequest } from './validation.js';

function integerEnv(env, key, fallback, min, max) {
  const value = env[key] === undefined || env[key] === '' ? fallback : Number(env[key]);
  if (!Number.isInteger(value) || value < min || value > max) throw new Error(`${key}_invalid`);
  return value;
}

export function loadConfig(env = process.env) {
  const stubVision = env.STUB_VISION === '1';
  const apiToken = env.API_BEARER_TOKEN || '';
  if (!stubVision && !apiToken) throw new Error('API_BEARER_TOKEN_required');
  if (!stubVision && !env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY_required');
  return {
    host: env.HOST || '0.0.0.0',
    port: integerEnv(env, 'PORT', 8080, 1, 65535),
    apiToken,
    geminiApiKey: env.GEMINI_API_KEY || '',
    geminiModel: env.GEMINI_MODEL || 'gemini-2.5-flash',
    stubVision,
    maxBodyBytes: integerEnv(env, 'MAX_BODY_BYTES', 12_000_000, 1024, 25_000_000),
    maxIntentChars: integerEnv(env, 'MAX_INTENT_CHARS', 2000, 1, 100_000),
    maxImageBase64Chars: integerEnv(env, 'MAX_IMAGE_BASE64_CHARS', 11_000_000, 4, 24_000_000),
    requestTimeoutMs: integerEnv(env, 'REQUEST_TIMEOUT_MS', 15_000, 1000, 120_000)
  };
}

function json(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'content-length': Buffer.byteLength(payload), 'cache-control': 'no-store' });
  res.end(payload);
}

function authenticate(req, expected) {
  const header = req.headers.authorization;
  if (typeof header !== 'string' || !header.startsWith('Bearer ')) return false;
  const supplied = Buffer.from(header.slice(7));
  const actual = Buffer.from(expected);
  return supplied.length === actual.length && timingSafeEqual(supplied, actual);
}

function readBody(req, maxBytes, timeoutMs) {
  return new Promise((resolve, reject) => {
    let total = 0;
    const chunks = [];
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      req.removeListener('data', onData);
      req.removeListener('end', onEnd);
      req.removeListener('error', onError);
      error ? reject(error) : resolve(value);
    };
    const onData = (chunk) => {
      total += chunk.length;
      if (total > maxBytes) {
        req.resume();
        finish(Object.assign(new Error('body_too_large'), { code: 'BODY_TOO_LARGE' }));
        return;
      }
      chunks.push(chunk);
    };
    const onEnd = () => finish(null, Buffer.concat(chunks).toString('utf8'));
    const onError = () => finish(new Error('body_read_failed'));
    const timer = setTimeout(() => finish(Object.assign(new Error('body_timeout'), { code: 'BODY_TIMEOUT' })), timeoutMs);
    req.on('data', onData).on('end', onEnd).on('error', onError);
  });
}

export function createRequestHandler({ config, vision }) {
  return async function handler(req, res) {
    if (req.method === 'GET' && req.url === '/health') {
      return json(res, 200, { status: 'ok' });
    }
    if (req.method !== 'POST' || req.url !== '/v1/decide') {
      return json(res, 404, { error: 'not_found' });
    }
    if (!config.stubVision && !authenticate(req, config.apiToken)) {
      return json(res, 401, { error: 'unauthorized' });
    }
    if (req.headers['content-type']?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
      return json(res, 415, { error: 'content_type_required' });
    }
    let raw;
    try {
      raw = await readBody(req, config.maxBodyBytes, config.requestTimeoutMs);
    } catch (error) {
      return json(res, error.code === 'BODY_TOO_LARGE' ? 413 : 408, { error: error.code === 'BODY_TOO_LARGE' ? 'request_too_large' : 'request_timeout' });
    }
    let input;
    try {
      input = JSON.parse(raw);
    } catch {
      return json(res, 400, { error: 'json_invalid' });
    }
    const checked = validateDecisionRequest(input, config);
    if (!checked.ok) return json(res, 400, { error: checked.error });
    try {
      const modelText = await vision.decide(checked.value);
      const decision = parseAndValidateModelText(modelText, { width: checked.value.width, height: checked.value.height });
      if (!decision.ok) return json(res, 503, SAFE_SPEAK);
      return json(res, 200, decision.value);
    } catch {
      return json(res, 503, SAFE_SPEAK);
    }
  };
}

export function createServer(config, vision = config.stubVision ? createStubVision() : createGeminiClient({ apiKey: config.geminiApiKey, model: config.geminiModel, timeoutMs: Math.max(1000, config.requestTimeoutMs - 1000) })) {
  const server = http.createServer(createRequestHandler({ config, vision }));
  server.requestTimeout = config.requestTimeoutMs;
  server.headersTimeout = Math.max(config.requestTimeoutMs + 1000, 5000);
  server.keepAliveTimeout = 5000;
  return server;
}
