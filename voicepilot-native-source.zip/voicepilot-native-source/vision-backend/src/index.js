import { createServer, loadConfig } from './server.js';

if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const config = loadConfig();
    const server = createServer(config);
    server.listen(config.port, config.host, () => {
      console.log(`voicepilot vision backend listening on ${config.host}:${config.port}`);
    });
  } catch (error) {
    console.error(`startup_failed: ${error.message}`);
    process.exitCode = 1;
  }
}

export * from './server.js';
export * from './validation.js';
export * from './gemini.js';
