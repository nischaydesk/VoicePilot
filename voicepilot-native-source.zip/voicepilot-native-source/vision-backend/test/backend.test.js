import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createServer, loadConfig } from '../src/server.js';
import { createStubVision } from '../src/gemini.js';
import { markHighRiskClickForConfirmation, parseAndValidateModelText, validateDecisionRequest, validateModelDecision } from '../src/validation.js';

const JPEG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10]).toString('base64');
const request = { intent: 'Open settings', image_base64: JPEG, mime_type: 'image/jpeg', screen_width: 1080, screen_height: 2400 };
const validModel = { action: 'CLICK', coordinates: { x: 10, y: 20 }, text_payload: 'Open settings', speech_response: 'Done.' };

function config(overrides = {}) {
  return { host: '127.0.0.1', port: 0, apiToken: 'test-token', geminiApiKey: 'test-key', geminiModel: 'test-model', stubVision: false, maxBodyBytes: 100000, maxIntentChars: 2000, maxImageBase64Chars: 10000, requestTimeoutMs: 2000, ...overrides };
}

function runRequest(server, options, body = '') {
  return new Promise((resolve, reject) => {
    const req = http.request({ ...options, port: server.address().port }, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(data) }));
    });
    req.on('error', reject);
    req.end(body);
  });
}

 test('strict request parser accepts canonical JPEG and rejects extra/malformed fields', () => {
  assert.equal(validateDecisionRequest(request).ok, true);
  assert.equal(validateDecisionRequest({ ...request, extra: true }).ok, false);
  assert.equal(validateDecisionRequest({ ...request, image_base64: 'not-base64' }).ok, false);
  assert.equal(validateDecisionRequest({ ...request, screen_width: 0 }).ok, false);
});

test('model parser validates exact schema and bounds', () => {
  assert.deepEqual(parseAndValidateModelText(JSON.stringify(validModel), { width: 100, height: 100 }).value, validModel);
  assert.equal(parseAndValidateModelText(JSON.stringify({ ...validModel, extra: 1 }), { width: 100, height: 100 }).ok, false);
  assert.equal(parseAndValidateModelText(JSON.stringify({ ...validModel, coordinates: { x: 100, y: 20 } }), { width: 100, height: 100 }).ok, false);
  assert.equal(parseAndValidateModelText(JSON.stringify({ ...validModel, text_payload: null }), { width: 100, height: 100 }).ok, false);
  assert.equal(parseAndValidateModelText('not json', { width: 100, height: 100 }).ok, false);
  const duplicateAction = '{"action":"CLICK","action":"SWIPE","coordinates":{"x":10,"y":20},"text_payload":"Open settings","speech_response":"Done."}';
  assert.equal(parseAndValidateModelText(duplicateAction, { width: 100, height: 100 }).error, 'model_json_duplicate_key');
  assert.equal(validateModelDecision({ ...validModel, speech_response: 'x'.repeat(321) }, { width: 100, height: 100 }).ok, false);
  assert.equal(validateModelDecision({ ...validModel, text_payload: 'x'.repeat(241) }, { width: 100, height: 100 }).ok, false);
});

test('action-specific field shapes stay consistent across the backend contract', () => {
  const dimensions = { width: 100, height: 100 };
  const type = { ...validModel, action: 'TYPE', coordinates: { x: 12, y: 34 }, text_payload: 'Banarasi Saree' };
  const swipe = { ...validModel, action: 'SWIPE', coordinates: { x: 12, y: 34 }, text_payload: null };
  const speak = { action: 'SPEAK', coordinates: null, text_payload: null, speech_response: 'Please review.' };
  assert.equal(validateModelDecision(type, dimensions).ok, true);
  assert.equal(validateModelDecision(swipe, dimensions).ok, true);
  assert.equal(validateModelDecision({ ...swipe, text_payload: 'not allowed' }, dimensions).ok, false);
  assert.equal(validateModelDecision(speak, dimensions).ok, true);
});

test('sensitive click remains a proposal and carries a confirmation warning for the Android gate', () => {
  const result = markHighRiskClickForConfirmation({ ...validModel, text_payload: 'Pay now', speech_response: 'Click Pay now.' });
  assert.equal(result.action, 'CLICK');
  assert.deepEqual(result.coordinates, validModel.coordinates);
  assert.equal(result.text_payload, 'Pay now');
  assert.match(result.speech_response, /confirm.*device/i);
});

test('configuration requires credentials unless stub mode is enabled', () => {
  assert.throws(() => loadConfig({ STUB_VISION: '0' }), /API_BEARER_TOKEN_required/);
  const loaded = loadConfig({ STUB_VISION: '1', PORT: '8099' });
  assert.equal(loaded.port, 8099);
});

test('HTTP auth, exact response schema, and model bounds', async (t) => {
  const vision = { decide: async () => JSON.stringify(validModel) };
  const server = createServer(config(), vision).listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  t.after(() => server.close());
  const base = { hostname: '127.0.0.1', method: 'POST', path: '/v1/decide', headers: { 'content-type': 'application/json' } };
  const unauth = await runRequest(server, base, JSON.stringify(request));
  assert.equal(unauth.status, 401);
  const ok = await runRequest(server, { ...base, headers: { ...base.headers, authorization: 'Bearer test-token' } }, JSON.stringify(request));
  assert.equal(ok.status, 200);
  assert.deepEqual(Object.keys(ok.body).sort(), ['action', 'coordinates', 'speech_response', 'text_payload']);
  assert.equal(ok.body.action, 'CLICK');
});

test('stub mode responds with safe exact action schema without auth', async (t) => {
  const server = createServer(config({ stubVision: true, apiToken: '' }), createStubVision()).listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  t.after(() => server.close());
  const result = await runRequest(server, { hostname: '127.0.0.1', method: 'POST', path: '/v1/decide', headers: { 'content-type': 'application/json' } }, JSON.stringify(request));
  assert.equal(result.status, 200);
  assert.deepEqual(Object.keys(result.body).sort(), ['action', 'coordinates', 'speech_response', 'text_payload']);
  assert.equal(result.body.action, 'SPEAK');
});
