# VoicePilot Vision Backend

Standalone Node.js 20+ HTTP backend that turns a Hindi/Hinglish voice intent and an Android JPEG screenshot into one proposed UI action. It uses the built-in `http` and `fetch` APIs and has no runtime dependencies. The backend cannot control a device or complete a transaction.

## Setup

```sh
cd vision-backend
# Set secrets in the shell or your deployment secret manager; .env files are not auto-loaded.
API_BEARER_TOKEN='replace-with-a-long-random-secret' GEMINI_API_KEY='server-only-key' npm start
```

Configuration comes from environment variables: `GEMINI_API_KEY`, `GEMINI_MODEL` (default `gemini-2.5-flash`), mandatory `API_BEARER_TOKEN` (unless test-only `STUB_VISION=1` is enabled), `HOST`, `PORT`, and optional body/timeout limits. Keep both keys out of the Android app and repository.

## API

- `GET /health` returns `{ "status": "ok" }` without authentication for health checks.
- `POST /v1/decide` requires `Authorization: Bearer $API_BEARER_TOKEN`, `Content-Type: application/json`, and exactly this request shape:

```json
{
  "intent": "Ek Banarasi saree dikhao",
  "image_base64": "<canonical base64 JPEG>",
  "mime_type": "image/jpeg",
  "screen_width": 1080,
  "screen_height": 2400
}
```

A successful response has exactly four keys. For example, a `TYPE` proposal requires coordinates for the visible input field:

```json
{
  "action": "TYPE",
  "coordinates": { "x": 500, "y": 900 },
  "text_payload": "Banarasi Saree",
  "speech_response": "Saree search kar di hai, pasand kijiye"
}
```

`action` is `CLICK`, `TYPE`, `SWIPE`, or `SPEAK`. `CLICK`, `TYPE`, and `SWIPE` require in-bounds integer coordinates. `CLICK.text_payload` is a non-empty visible target label; `TYPE.text_payload` is the text to enter; each text payload is at most 240 characters. `SWIPE` and `SPEAK` require a null payload. `SPEAK` also requires null coordinates. `speech_response` is at most 320 characters. Both the backend and Android client reject unknown fields, invalid action names, duplicate JSON object keys, malformed values and out-of-range coordinates. Invalid model output fails closed to a safe `SPEAK` proposal.

## Safety and privacy boundaries

The prompt treats screenshot text as untrusted and follows only the user intent. The server never executes an action. It leaves a high-risk click as a proposal but adds a warning phrase that the Android gate recognizes; other clients must independently implement a human confirmation gate. The Android client pauses checkout/payment/order-related clicks, asks through Hindi TTS, shows the exact target in the floating confirmation card and withholds dispatch until a fresh affirmative voice answer or explicit Confirm tap. It cancels on UI changes, new commands, timeout, interruption, or missing semantic target; a sensitive confirmed tap uses an exact currently visible accessibility label, never coordinate fallback. The client refuses to type passwords, payment credentials, OTP, PIN and similar sensitive input.

The backend does not log raw intents, screenshots, request bodies, API keys or model payloads, but image/text are sent to the configured vision provider. Review that provider's current data-retention terms before deployment. Requests are authenticated and bounded (12 MB default); canonical base64, JPEG markers, dimensions and model schemas are checked, and HTTP/model calls have timeouts. The marker check is not a full image decoder. The API does not include rate limiting; put it behind an HTTPS ingress/API gateway with limits, monitoring, key rotation and restricted network access. `STUB_VISION=1` intentionally disables authentication and must never be exposed beyond local testing; its only response is a safe `SPEAK` proposal.

## Local test

```sh
npm test
```

The built-in `node:test` suite covers request validation, strict action parsing and bounds, duplicate keys, risk-warning output, bearer authentication, HTTP response schema and the non-actioning stub.
